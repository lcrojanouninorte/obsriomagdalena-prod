
var styleJSON = {
    "version": 8,
    "name": "qgis2web export",
    "pitch": 0,
    "light": {
        "intensity": 0.2
    },
    "sources": {
        "Frecuenciadeobservacindeagua_0": {
            "type": "image",
            "url": "./data/Frecuenciadeobservacindeagua_0.png",
            "coordinates": [
                [-75.000341, 6.391442],
                [-73.695091, 6.391442],
                [-73.695091, 11.153192],
                [-75.000341, 11.153192]
            ]
        }},
    "sprite": "",
    "glyphs": "https://glfonts.lukasmartinelli.ch/fonts/{fontstack}/{range}.pbf",
    "layers": [
        {
            "id": "background",
            "type": "background",
            "layout": {},
            "paint": {
                "background-color": "#ffffff"
            }
        },
        {
            "id": "lyr_Frecuenciadeobservacindeagua_0_0",
            "type": "raster",
            "source": "Frecuenciadeobservacindeagua_0",
            "minzoom": 0,
            "maxzoom": 22
        }],
}